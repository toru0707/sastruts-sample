/**
 * Created on 18 juil. 2002
 *
 * To change this generated comment edit the template variable "filecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of file comments go to
 * Window>Preferences>Java>Code Generation.
 */
package com.sysdeo.eclipse.tomcat.actions;

/**
 * @author Administrateur
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class TomcatActionException extends Exception {
	/**
	 * Constructor TomcatActionException.
	 * @param string
	 */
	public TomcatActionException(String message) {
		super(message);
	}


}
